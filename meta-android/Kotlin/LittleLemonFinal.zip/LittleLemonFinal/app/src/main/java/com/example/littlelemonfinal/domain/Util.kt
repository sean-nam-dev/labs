package com.example.littlelemonfinal.domain

object Util {
    const val START_DESTINATION = "start_destination"
}