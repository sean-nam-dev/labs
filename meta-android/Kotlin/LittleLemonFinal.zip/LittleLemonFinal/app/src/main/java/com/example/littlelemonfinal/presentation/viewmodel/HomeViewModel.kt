package com.example.littlelemonfinal.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.littlelemonfinal.domain.model.Menu
import com.example.littlelemonfinal.domain.usecase.NetworkFetchUsecase
import com.example.littlelemonfinal.presentation.action.HomeAction
import com.example.littlelemonfinal.util.FilterType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

class HomeViewModel(
    private val networkFetchUsecase: NetworkFetchUsecase
) : ViewModel(), HomeAction {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = ""
    )

    private val _filter = MutableStateFlow<FilterType>(FilterType.None)
    val filter = _filter.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = FilterType.None
    )

    val menuList = combine(searchQuery, filter) { search, filter ->
        networkFetchUsecase().filter {
            (it.title.contains(search) || it.description.contains(search))
                    && (filter == FilterType.None || it.category == filter.value)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = emptyList()
    )

    override fun onSearchQuery(query: String) {
        _searchQuery.update { query }
    }

    override fun onFilter(type: FilterType) {
        _filter.update { type }
    }
}